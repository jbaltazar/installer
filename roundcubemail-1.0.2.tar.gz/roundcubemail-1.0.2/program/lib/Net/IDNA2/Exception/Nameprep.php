<?php
require_once 'Net/IDNA2/Exception.php';

class Net_IDNA2_Exception_Nameprep extends Net_IDNA2_Exception
{
}
